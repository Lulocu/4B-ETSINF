

Java.perform(function () {
	
	
	var callmeActivity = Java.use("com.ironhackers.androidlab.Callme");

	callmeActivity.onCreate.implementation = function(bundle) {
				console.log('');
				console.log("> Ejecutando onCreate(...) ");
				this.onCreate(bundle);
				console.log("> Invocando call:me_win() ");
				this.call_me_win();
	};
		
});