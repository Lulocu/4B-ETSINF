package com.example.holamundo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView s = findViewById(R.id.tvMensaje);
        s.setText(R.string.mensaje);
        Log.d( "holamundo.MainActivity", "Mensaje cambiado en onCreate");
        findViewById(R.id.imageView).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                    startActivity(new Intent(getApplicationContext(),creditos.class));
                }
            }
        );
        ((Button)findViewById(R.id.button)).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //generar toast que muestre lo escrito en el textedit
                        //if (nada escrito) print("No has escrito nada!")
                        EditText text = (EditText) findViewById(R.id.et_Contrasenya);
                        String value = text.getText().toString();
                        Log.d("holamundo.MainActivity", value);
                        if (value.equals("")) { Toast.makeText(getApplicationContext(),"No has escrito nada!", Toast.LENGTH_SHORT).show(); }
                        else { Toast.makeText(getApplicationContext(),value, Toast.LENGTH_SHORT).show(); }
                    }
                }
        );
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("holamundo.MainActivity","onStart");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d("holamundo.MainActivity","onResume");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d("holamundo.MainActivity","onPause");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d("holamundo.MainActivity","onStop");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d("holamundo.MainActivity","onDestroy");
    }
}