package com.example.holamundo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class creditos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creditos);
        TextView s = findViewById(R.id.creditosNombres);
        TextView c = findViewById(R.id.creditosCorreos);
        s.setText(R.string.nombres);
        c.setText(R.string.correos);
        Log.d("holamundo.creditos", "créditos mostrados");
    }
}