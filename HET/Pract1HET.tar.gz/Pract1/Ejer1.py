banana = "fruta"
cantBanana = 89
#print(banana)

for i in range(3,10,2):
    #print(i)
    break

lista1 = [3,'q',9,8,6]

for i in lista1:
    #print(i)
    break

dicc1= {'hola':9,43:'adios'}
print(dicc1['hola'])
tupla = ('l',9)
print(tupla)