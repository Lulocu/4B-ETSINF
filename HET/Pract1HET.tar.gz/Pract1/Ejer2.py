print('Hola?')
resp = input()
print('¿Como me dices?', resp)