#!/usr/bin/env python3
import sys;
import os;

fn = "kk.txt"
if not os.path.exists(fn):
    f=open(fn, 'w');
    f.write("1");
    f.close();

fr = open(fn, 'r+')
daton = int(fr.read());
fr.seek(0,0);
fr.write(str(daton+1));
fr.close();

print ("HTTP/1.1 200 OK\r\n\r\n<html><body><h1>Connections: %d</h1></body></html>" % (daton));
